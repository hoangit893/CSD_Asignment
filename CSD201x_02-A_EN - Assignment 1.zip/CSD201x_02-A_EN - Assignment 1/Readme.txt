Comment and explain about 3 algorithms :
* BubbleSort : is a straight-forward comparison sort algorithm that continuously compares adjacent indexes and swaps them if they are out of order.
It is easy to understand but not efficient because it make loops n^2 to finish (with n is length of array) . Big-O runtime :
            + Best case : O(n) 
            + Average : O (n^2)
            + Worst case : O (n^2) 
* Insertion Sort :  is a stable comparison sort algorithm with poor performance. Insertion Sort uses the insertion method and while it can perform at O(n) in the best case, it performs at O(n2) in the average and worst case.
Relatively good for small lists , relatively good for partially sorted lists . Big-O runtime :
            + Best case : O(n) 
            + Average : O (n^2)
            + Worst case : O (n^2) 
* Selection Sort : Selection Sort is an unstable comparison sort algorithm with poor performance. Selection Sort uses the selection method and performs at O(n2) in the best, average, and worst case.
Better than bubble sort, running time is independent of ordering of elements .Big-O runtime :
            + Best case : O(n^2) 
            + Average : O (n^2)
            + Worst case : O (n^2) 



